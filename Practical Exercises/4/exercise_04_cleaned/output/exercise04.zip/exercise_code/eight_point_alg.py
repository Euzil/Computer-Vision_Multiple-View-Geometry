import numpy as np

from .utils import skewMat

def transformImgCoord(x1, x2, y1, y2, K1, K2):
    assert x1.shape == y1.shape == x2.shape == y2.shape

    pts1_homo = np.stack([x1, y1, np.ones_like(x1)], axis=0)
    pts2_homo = np.stack([x2, y2, np.ones_like(x2)], axis=0)

    x1_cam = np.linalg.inv(K1) @ pts1_homo
    x2_cam = np.linalg.inv(K2) @ pts2_homo

    return x1_cam[0], x2_cam[0], x1_cam[1], x2_cam[1]

def constructChiMatrix(x1, x2, y1, y2):
    n = x1.shape[0]
    chi = np.zeros((n, 9))
    for i in range(n):
        p1 = np.array([x1[i], y1[i], 1])
        p2 = np.array([x2[i], y2[i], 1])
        chi[i] = np.kron(p2, p1)
    return chi

def solveForEssentialMatrix(chi_mat):
    _, _, Vt = np.linalg.svd(chi_mat)
    E_vec = Vt[-1]
    E = E_vec.reshape(3, 3)

    U, S, Vt = np.linalg.svd(E)

    if np.linalg.det(U) < 0:
        U[:, -1] *= -1
    if np.linalg.det(Vt) < 0:
        Vt[-1, :] *= -1

    S_corrected = np.diag([1, 1, 0])
    E = U @ S_corrected @ Vt

    return E, U, Vt, S_corrected

def constructEssentialMatrix(x1, x2, y1, y2, K1, K2):
    x1, x2, y1, y2 = transformImgCoord(x1, x2, y1, y2, K1, K2)
    chi_mat = constructChiMatrix(x1, x2, y1, y2)
    E, U, Vt, S = solveForEssentialMatrix(chi_mat)
    return E, U, Vt, S

def recoverPose(U, Vt, S):
    W = np.array([[0, -1, 0],
                  [1,  0, 0],
                  [0,  0, 1]])

    R1 = U @ W @ Vt
    R2 = U @ W.T @ Vt

    if np.linalg.det(R1) < 0:
        R1 = -R1
    if np.linalg.det(R2) < 0:
        R2 = -R2

    T = U[:, 2]
    return R1, R2, T, -T

def reconstruct(x1, x2, y1, y2, R, T):
    n = x1.shape[0]
    X1 = np.zeros((3, n))

    for i in range(n):
        p1 = np.array([x1[i], y1[i], 1])
        p2 = np.array([x2[i], y2[i], 1])

        P1 = np.hstack((np.eye(3), np.zeros((3, 1))))
        P2 = np.hstack((R, T.reshape(3, 1)))

        A = np.array([
            p1[1] * P1[2] - P1[1],
            P1[0] - p1[0] * P1[2],
            p2[1] * P2[2] - P2[1],
            P2[0] - p2[0] * P2[2]
        ])

        _, _, Vt = np.linalg.svd(A)
        X_hom = Vt[-1]
        if abs(X_hom[3]) < 1e-8:
            return None, None
        X1[:, i] = X_hom[:3] / X_hom[3]

    X2 = R @ X1 + T.reshape(3, 1)

    if np.all(X1[2, :] > 0) and np.all(X2[2, :] > 0):
        return X1, X2
    return None, None

def allReconstruction(x1, x2, y1, y2, R1, R2, T1, T2, K1, K2):
    x1, x2, y1, y2 = transformImgCoord(x1, x2, y1, y2, K1, K2)

    candidates = [(R1, T1), (R1, T2), (R2, T1), (R2, T2)]
    best_X1, best_X2, best_R, best_T = None, None, None, None

    for R, T in candidates:
        X1, X2 = reconstruct(x1, x2, y1, y2, R, T)
        if X1 is not None:
            best_X1, best_X2 = X1, X2
            best_R, best_T = R, T
            break

    return best_R, best_T, best_X1, best_X2
